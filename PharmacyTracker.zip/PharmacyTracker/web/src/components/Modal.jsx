import { useEffect, useRef } from 'react'

/**
 * Accessible modal dialog for feedback (success / error / info).
 * Replaces toast notifications.
 */
export default function Modal({ open, type = 'info', title, message, onClose, confirmLabel = 'OK' }) {
  const btnRef = useRef(null)

  useEffect(() => {
    if (!open) return
    btnRef.current?.focus()
    const onKey = (e) => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onClose])

  if (!open) return null

  const icon = type === 'success' ? '✓' : type === 'error' ? '!' : 'i'
  const defaultTitle =
    title || (type === 'success' ? 'Success' : type === 'error' ? 'Something went wrong' : 'Notice')

  return (
    <div
      className="dialog-backdrop"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
      onClick={(e) => { if (e.target === e.currentTarget) onClose() }}
    >
      <div className="dialog sm">
        <div className={`dialog-icon ${type}`} aria-hidden="true">{icon}</div>
        <h3 id="modal-title" style={{ textAlign: 'center' }}>{defaultTitle}</h3>
        <p className="msg">{message}</p>
        <div className="form-actions" style={{ justifyContent: 'center' }}>
          <button
            ref={btnRef}
            className={`btn ${type === 'error' ? 'danger' : type === 'success' ? 'success' : ''}`}
            onClick={onClose}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  )
}
