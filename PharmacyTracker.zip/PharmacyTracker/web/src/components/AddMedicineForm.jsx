import { useState } from 'react'

const todayIso = () => new Date().toISOString().slice(0, 10)

const initial = {
  name: '', brand: '', expiryDate: '', quantity: '', price: '', notes: ''
}

function validate(v) {
  const err = {}
  if (!v.name?.trim()) err.name = 'Name is required.'
  else if (v.name.trim().length > 120) err.name = 'Max 120 characters.'
  if (!v.brand?.trim()) err.brand = 'Brand is required.'
  else if (v.brand.trim().length > 80) err.brand = 'Max 80 characters.'
  if (!v.expiryDate) err.expiryDate = 'Expiry date is required.'
  else if (v.expiryDate < todayIso()) err.expiryDate = 'Expiry date cannot be in the past.'
  const q = Number(v.quantity)
  if (v.quantity === '' || Number.isNaN(q)) err.quantity = 'Quantity is required.'
  else if (!Number.isInteger(q) || q < 0) err.quantity = 'Must be a non-negative integer.'
  const p = Number(v.price)
  if (v.price === '' || Number.isNaN(p)) err.price = 'Price is required.'
  else if (p < 0) err.price = 'Price cannot be negative.'
  else if (!/^\d+(\.\d{1,2})?$/.test(String(v.price))) err.price = 'Use up to 2 decimal places.'
  if (v.notes && v.notes.length > 1000) err.notes = 'Max 1000 characters.'
  return err
}

export default function AddMedicineForm({ onSubmit }) {
  const [values, setValues] = useState(initial)
  const [touched, setTouched] = useState({})
  const [submitting, setSubmitting] = useState(false)
  const errors = validate(values)
  const isValid = Object.keys(errors).length === 0

  const set = (k) => (e) => setValues(v => ({ ...v, [k]: e.target.value }))
  const blur = (k) => () => setTouched(t => ({ ...t, [k]: true }))
  const showErr = (k) => touched[k] && errors[k]

  const submit = async (e) => {
    e.preventDefault()
    setTouched({ name: true, brand: true, expiryDate: true, quantity: true, price: true, notes: true })
    if (!isValid) return
    setSubmitting(true)
    const ok = await onSubmit({
      name: values.name.trim(),
      brand: values.brand.trim(),
      expiryDate: new Date(values.expiryDate + 'T00:00:00Z').toISOString(),
      quantity: Number(values.quantity),
      price: Number(values.price),
      notes: values.notes?.trim() || null
    })
    setSubmitting(false)
    if (ok) { setValues(initial); setTouched({}) }
  }

  return (
    <form onSubmit={submit} noValidate>
      <div className="form-grid">
        <div className={`field ${showErr('name') ? 'invalid' : ''}`}>
          <label htmlFor="f-name">Name <span style={{color:'var(--danger)'}}>*</span></label>
          <input id="f-name" value={values.name} onChange={set('name')} onBlur={blur('name')} placeholder="e.g. Paracetamol 500mg" maxLength={120} />
          <div className="err">{showErr('name') || ''}</div>
        </div>
        <div className={`field ${showErr('brand') ? 'invalid' : ''}`}>
          <label htmlFor="f-brand">Brand <span style={{color:'var(--danger)'}}>*</span></label>
          <input id="f-brand" value={values.brand} onChange={set('brand')} onBlur={blur('brand')} placeholder="e.g. Cipla" maxLength={80} />
          <div className="err">{showErr('brand') || ''}</div>
        </div>
        <div className={`field ${showErr('expiryDate') ? 'invalid' : ''}`}>
          <label htmlFor="f-expiry">Expiry Date <span style={{color:'var(--danger)'}}>*</span></label>
          <input id="f-expiry" type="date" value={values.expiryDate} min={todayIso()} onChange={set('expiryDate')} onBlur={blur('expiryDate')} />
          <div className="err">{showErr('expiryDate') || ''}</div>
        </div>
        <div className={`field ${showErr('quantity') ? 'invalid' : ''}`}>
          <label htmlFor="f-qty">Quantity <span style={{color:'var(--danger)'}}>*</span></label>
          <input id="f-qty" type="number" min="0" step="1" value={values.quantity} onChange={set('quantity')} onBlur={blur('quantity')} inputMode="numeric" />
          <div className="err">{showErr('quantity') || ''}</div>
        </div>
        <div className={`field ${showErr('price') ? 'invalid' : ''}`}>
          <label htmlFor="f-price">Price (₹) <span style={{color:'var(--danger)'}}>*</span></label>
          <input id="f-price" type="number" min="0" step="0.01" value={values.price} onChange={set('price')} onBlur={blur('price')} inputMode="decimal" />
          <div className="err">{showErr('price') || ''}</div>
        </div>
        <div className={`field ${showErr('notes') ? 'invalid' : ''}`} style={{ gridColumn: '1 / -1' }}>
          <label htmlFor="f-notes">Notes</label>
          <textarea id="f-notes" value={values.notes} onChange={set('notes')} onBlur={blur('notes')} placeholder="Optional notes (not shown in grid)" maxLength={1000} />
          <div className="err">{showErr('notes') || ''}</div>
        </div>
      </div>
      <div className="form-actions">
        <button type="button" className="btn ghost" onClick={() => { setValues(initial); setTouched({}) }} disabled={submitting}>Reset</button>
        <button type="submit" className="btn" disabled={!isValid || submitting}>
          {submitting ? <><span className="spinner" /> Saving...</> : 'Add Medicine'}
        </button>
      </div>
    </form>
  )
}
