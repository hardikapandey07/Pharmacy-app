import { useEffect, useRef, useState } from 'react'
import { inr } from '../api.js'

export default function SellDialog({ medicine, onCancel, onConfirm }) {
  const [qty, setQty] = useState(1)
  const [submitting, setSubmitting] = useState(false)
  const inputRef = useRef(null)

  useEffect(() => { inputRef.current?.focus() }, [])
  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') onCancel() }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onCancel])

  const q = Number(qty)
  const invalidReason =
    !Number.isInteger(q) || q <= 0 ? 'Quantity must be a positive whole number.' :
    q > medicine.quantity ? `Only ${medicine.quantity} in stock.` : null

  const total = invalidReason ? 0 : q * medicine.price

  const submit = async (e) => {
    e.preventDefault()
    if (invalidReason) return
    setSubmitting(true)
    await onConfirm({ medicineId: medicine.id, quantity: q })
    setSubmitting(false)
  }

  return (
    <div className="dialog-backdrop" role="dialog" aria-modal="true" aria-labelledby="sell-title" onClick={(e) => { if (e.target === e.currentTarget) onCancel() }}>
      <div className="dialog">
        <h3 id="sell-title">Record a sale</h3>
        <div className="meta">
          <strong>{medicine.name}</strong> — {medicine.brand}<br />
          In stock: {medicine.quantity} · Unit price: {inr(medicine.price)}
        </div>
        <form onSubmit={submit}>
          <div className={`field ${invalidReason ? 'invalid' : ''}`}>
            <label htmlFor="sell-qty">Quantity</label>
            <input
              id="sell-qty" ref={inputRef} type="number" inputMode="numeric"
              min="1" max={medicine.quantity} step="1" value={qty}
              onChange={(e) => setQty(e.target.value)}
            />
            <div className="err">{invalidReason || ''}</div>
          </div>
          <div className="meta" aria-live="polite">
            Total: <strong>{inr(total)}</strong>
          </div>
          <div className="form-actions">
            <button type="button" className="btn ghost" onClick={onCancel} disabled={submitting}>Cancel</button>
            <button type="submit" className="btn" disabled={!!invalidReason || submitting}>
              {submitting ? <><span className="spinner" /> Selling...</> : 'Confirm sale'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
