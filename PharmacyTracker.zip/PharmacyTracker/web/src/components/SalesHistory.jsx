import { inr } from '../api.js'

function fmt(iso) {
  const d = new Date(iso)
  return d.toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })
}

export default function SalesHistory({ sales, onRefresh }) {
  const total = sales.reduce((s, x) => s + (x.totalPrice || 0), 0)
  return (
    <>
      <div className="toolbar" style={{ marginBottom: 10 }}>
        <div style={{ marginRight: 'auto' }}>
          <span className="pill">{sales.length} sale{sales.length === 1 ? '' : 's'}</span>{' '}
          <span className="pill fresh">Revenue: {inr(total)}</span>
        </div>
        <button className="btn ghost sm" onClick={onRefresh}>Refresh</button>
      </div>
      {sales.length === 0 ? (
        <div className="empty">No sales yet. Record one from the Inventory tab.</div>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>When</th>
                <th>Medicine</th>
                <th>Qty</th>
                <th>Unit Price</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              {sales.map(s => (
                <tr key={s.id}>
                  <td>{fmt(s.soldAtUtc)}</td>
                  <td><strong>{s.medicineName}</strong></td>
                  <td>{s.quantity}</td>
                  <td>{inr(s.unitPrice)}</td>
                  <td>{inr(s.totalPrice)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  )
}
