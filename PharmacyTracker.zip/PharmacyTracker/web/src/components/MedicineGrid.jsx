import { memo } from 'react'
import { daysUntil, rowFlag, inr } from '../api.js'

function fmtDate(iso) {
  const d = new Date(iso)
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
}

function Row({ m, onSell }) {
  const flag = rowFlag(m)
  const d = daysUntil(m.expiryDate)
  return (
    <tr className={flag} data-testid="med-row">
      <td>
        <strong>{m.name}</strong>
      </td>
      <td>{m.brand}</td>
      <td>
        {fmtDate(m.expiryDate)}
        {flag === 'expiring' && (
          <div>
            <span className="pill expiring">
              {d < 0 ? 'Expired' : `${d} day${d === 1 ? '' : 's'} left`}
            </span>
          </div>
        )}
      </td>
      <td>
        {m.quantity}
        {flag === 'low-stock' && <div><span className="pill low-stock">Low stock</span></div>}
      </td>
      <td>{inr(m.price)}</td>
      <td className="row-actions">
        <button className="btn sm" onClick={() => onSell(m)} disabled={m.quantity <= 0} aria-label={`Sell ${m.name}`}>
          Sell
        </button>
      </td>
    </tr>
  )
}

function MedicineGrid({ medicines, onSell }) {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Brand</th>
            <th>Expiry Date</th>
            <th>Qty</th>
            <th>Price</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {medicines.map((m) => <Row key={m.id} m={m} onSell={onSell} />)}
        </tbody>
      </table>
    </div>
  )
}
export default memo(MedicineGrid)
