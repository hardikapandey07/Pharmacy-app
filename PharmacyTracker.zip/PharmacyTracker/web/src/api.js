// Tiny API layer with abort-safe requests + micro-cache
const BASE = ''  // same-origin when served from ASP.NET; proxy handles dev

async function request(path, opts = {}) {
  const res = await fetch(BASE + path, {
    headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) },
    ...opts
  })
  if (!res.ok) {
    let payload = null
    try { payload = await res.json() } catch { /* no body */ }
    const msg = payload?.message || payload?.title || `Request failed (${res.status})`
    const err = new Error(msg)
    err.status = res.status
    err.payload = payload
    throw err
  }
  if (res.status === 204) return null
  return res.json()
}

// Simple in-memory cache for /api/medicines with configurable TTL
const cache = new Map()
const TTL_MS = 3000

export async function getMedicines({ search = '', signal } = {}) {
  const key = `meds:${search.toLowerCase()}`
  const now = Date.now()
  const hit = cache.get(key)
  if (hit && now - hit.at < TTL_MS) return hit.data
  const qs = search ? `?search=${encodeURIComponent(search)}` : ''
  const data = await request(`/api/medicines${qs}`, { signal })
  cache.set(key, { at: now, data })
  return data
}

export function invalidateMedicinesCache() {
  for (const k of [...cache.keys()]) if (k.startsWith('meds:')) cache.delete(k)
}

export async function addMedicine(payload) {
  const created = await request('/api/medicines', { method: 'POST', body: JSON.stringify(payload) })
  invalidateMedicinesCache()
  return created
}

export async function getSales({ signal } = {}) {
  return request('/api/sales', { signal })
}

export async function recordSale(payload) {
  const sale = await request('/api/sales', { method: 'POST', body: JSON.stringify(payload) })
  invalidateMedicinesCache()
  return sale
}

// Pure helpers (also exported for unit tests)
export function daysUntil(dateIso) {
  const expiry = new Date(dateIso)
  const today = new Date()
  const msPerDay = 1000 * 60 * 60 * 24
  return Math.floor((expiry.setHours(0,0,0,0) - today.setHours(0,0,0,0)) / msPerDay)
}
export function rowFlag(med) {
  const d = daysUntil(med.expiryDate)
  if (d < 30) return 'expiring'   // red
  if (med.quantity < 10) return 'low-stock' // yellow
  return ''
}
export function inr(n) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: 2 }).format(n)
}
