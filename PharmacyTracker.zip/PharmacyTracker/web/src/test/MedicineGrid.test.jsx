import { describe, it, expect, vi } from 'vitest'
import { render, screen } from '@testing-library/react'
import MedicineGrid from '../components/MedicineGrid.jsx'

const soon = new Date(); soon.setDate(soon.getDate() + 10)
const far  = new Date();  far.setFullYear(far.getFullYear() + 1)

const meds = [
  { id: '1', name: 'Paracetamol', brand: 'Cipla', expiryDate: far.toISOString(), quantity: 50, price: 25 },
  { id: '2', name: 'Amoxicillin', brand: 'Sun',   expiryDate: far.toISOString(), quantity: 5,  price: 80 },
  { id: '3', name: 'Cetirizine',  brand: 'DRL',   expiryDate: soon.toISOString(), quantity: 40, price: 30 }
]

describe('MedicineGrid', () => {
  it('renders row for each medicine', () => {
    render(<MedicineGrid medicines={meds} onSell={() => {}} />)
    expect(screen.getAllByTestId('med-row')).toHaveLength(3)
  })
  it('applies expiring class on near-expiry rows', () => {
    const { container } = render(<MedicineGrid medicines={meds} onSell={() => {}} />)
    const rows = container.querySelectorAll('tr.expiring')
    expect(rows.length).toBe(1)
  })
  it('applies low-stock class on low quantity rows', () => {
    const { container } = render(<MedicineGrid medicines={meds} onSell={() => {}} />)
    const rows = container.querySelectorAll('tr.low-stock')
    expect(rows.length).toBe(1)
  })
  it('does NOT show Notes column', () => {
    render(<MedicineGrid medicines={meds} onSell={() => {}} />)
    expect(screen.queryByRole('columnheader', { name: /notes/i })).toBeNull()
  })
  it('calls onSell with the medicine', async () => {
    const onSell = vi.fn()
    render(<MedicineGrid medicines={meds} onSell={onSell} />)
    const btns = screen.getAllByRole('button', { name: /sell/i })
    btns[0].click()
    expect(onSell).toHaveBeenCalledWith(meds[0])
  })
})
