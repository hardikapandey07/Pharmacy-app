import { describe, it, expect, vi } from 'vitest'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import AddMedicineForm from '../components/AddMedicineForm.jsx'

describe('AddMedicineForm', () => {
  it('blocks submission when required fields are empty', async () => {
    const onSubmit = vi.fn()
    render(<AddMedicineForm onSubmit={onSubmit} />)
    const btn = screen.getByRole('button', { name: /add medicine/i })
    expect(btn).toBeDisabled()
    await userEvent.click(btn)
    expect(onSubmit).not.toHaveBeenCalled()
  })

  it('submits with valid data', async () => {
    const user = userEvent.setup()
    const onSubmit = vi.fn().mockResolvedValue(true)
    render(<AddMedicineForm onSubmit={onSubmit} />)
    await user.type(screen.getByLabelText(/name/i), 'Crocin')
    await user.type(screen.getByLabelText(/brand/i), 'GSK')
    const future = new Date(); future.setFullYear(future.getFullYear() + 1)
    const iso = future.toISOString().slice(0, 10)
    const dateInput = screen.getByLabelText(/expiry date/i)
    await user.clear(dateInput); await user.type(dateInput, iso)
    await user.type(screen.getByLabelText(/quantity/i), '25')
    await user.type(screen.getByLabelText(/price/i), '12.50')
    await user.click(screen.getByRole('button', { name: /add medicine/i }))
    expect(onSubmit).toHaveBeenCalledTimes(1)
    const payload = onSubmit.mock.calls[0][0]
    expect(payload.name).toBe('Crocin')
    expect(payload.quantity).toBe(25)
    expect(payload.price).toBe(12.5)
  })

  it('rejects price with more than 2 decimals', async () => {
    const user = userEvent.setup()
    const onSubmit = vi.fn()
    render(<AddMedicineForm onSubmit={onSubmit} />)
    await user.type(screen.getByLabelText(/price/i), '10.123')
    await user.tab()
    expect(screen.getByText(/up to 2 decimal/i)).toBeInTheDocument()
  })
})
