import { describe, it, expect } from 'vitest'
import { daysUntil, rowFlag, inr } from '../api.js'

describe('daysUntil', () => {
  it('returns positive for future dates', () => {
    const d = new Date()
    d.setDate(d.getDate() + 10)
    expect(daysUntil(d.toISOString())).toBe(10)
  })
  it('returns negative for past dates', () => {
    const d = new Date()
    d.setDate(d.getDate() - 2)
    expect(daysUntil(d.toISOString())).toBe(-2)
  })
})

describe('rowFlag', () => {
  const soon = new Date(); soon.setDate(soon.getDate() + 10)
  const far = new Date();  far.setDate(far.getDate() + 365)
  it('flags expiring', () => {
    expect(rowFlag({ expiryDate: soon.toISOString(), quantity: 100 })).toBe('expiring')
  })
  it('flags low stock', () => {
    expect(rowFlag({ expiryDate: far.toISOString(), quantity: 5 })).toBe('low-stock')
  })
  it('flags expiring over low-stock when both', () => {
    expect(rowFlag({ expiryDate: soon.toISOString(), quantity: 2 })).toBe('expiring')
  })
  it('returns empty when healthy', () => {
    expect(rowFlag({ expiryDate: far.toISOString(), quantity: 100 })).toBe('')
  })
})

describe('inr', () => {
  it('formats in INR with 2 decimals', () => {
    const s = inr(1234.5)
    expect(s).toMatch(/1,234\.50/)
  })
})
