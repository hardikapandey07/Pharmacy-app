import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { getMedicines, addMedicine, recordSale, getSales } from './api.js'
import MedicineGrid from './components/MedicineGrid.jsx'
import AddMedicineForm from './components/AddMedicineForm.jsx'
import SellDialog from './components/SellDialog.jsx'
import SalesHistory from './components/SalesHistory.jsx'
import Modal from './components/Modal.jsx'

const REFRESH_MS = 15000

export default function App() {
  const [tab, setTab] = useState('inventory')
  const [medicines, setMedicines] = useState([])
  const [sales, setSales] = useState([])
  const [search, setSearch] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [sellTarget, setSellTarget] = useState(null)
  const [modal, setModal] = useState({ open: false, type: 'info', title: '', message: '' })
  const abortRef = useRef(null)

  const showModal = (type, message, title) => setModal({ open: true, type, title, message })
  const closeModal = () => setModal((m) => ({ ...m, open: false }))

  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search.trim()), 250)
    return () => clearTimeout(t)
  }, [search])

  const loadMedicines = useCallback(async () => {
    abortRef.current?.abort()
    const ctrl = new AbortController()
    abortRef.current = ctrl
    try {
      setError(null)
      const data = await getMedicines({ search: debouncedSearch, signal: ctrl.signal })
      setMedicines(data)
    } catch (e) {
      if (e.name !== 'AbortError') setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [debouncedSearch])

  const loadSales = useCallback(async () => {
    try { setSales(await getSales()) } catch { /* non-critical */ }
  }, [])

  useEffect(() => { loadMedicines() }, [loadMedicines])
  useEffect(() => { if (tab === 'sales') loadSales() }, [tab, loadSales])

  useEffect(() => {
    const id = setInterval(() => {
      if (document.hidden) return
      loadMedicines()
      if (tab === 'sales') loadSales()
    }, REFRESH_MS)
    return () => clearInterval(id)
  }, [loadMedicines, loadSales, tab])

  const handleAdd = async (payload) => {
    try {
      await addMedicine(payload)
      showModal('success', `${payload.name} has been added to the inventory.`, 'Medicine added')
      await loadMedicines()
      return true
    } catch (e) {
      showModal('error', e.message)
      return false
    }
  }

  const handleSell = async ({ medicineId, quantity }) => {
    try {
      const sale = await recordSale({ medicineId, quantity })
      showModal('success', `Sold ${quantity} x ${sale.medicineName} for a total of ₹${sale.totalPrice.toFixed(2)}.`, 'Sale recorded')
      setSellTarget(null)
      await loadMedicines()
      return true
    } catch (e) {
      showModal('error', e.message)
      return false
    }
  }

  const stats = useMemo(() => {
    const expiring = medicines.filter(m => {
      const d = (new Date(m.expiryDate) - new Date()) / (1000*60*60*24)
      return d < 30
    }).length
    const low = medicines.filter(m => m.quantity < 10).length
    return { total: medicines.length, expiring, low }
  }, [medicines])

  return (
    <div className="app">
      <header className="app-header">
        <div className="brand">
          <div className="brand-mark" aria-hidden="true">Rx</div>
          <div>
            <h1>ABC Pharmacy</h1>
            <p>Medicine Inventory &amp; Sales</p>
          </div>
        </div>
        <div className="tabs" role="tablist" aria-label="Sections">
          <button role="tab" aria-selected={tab === 'inventory'} className="tab" onClick={() => setTab('inventory')}>Inventory</button>
          <button role="tab" aria-selected={tab === 'add'} className="tab" onClick={() => setTab('add')}>Add Medicine</button>
          <button role="tab" aria-selected={tab === 'sales'} className="tab" onClick={() => setTab('sales')}>Sales</button>
        </div>
      </header>

      {tab === 'inventory' && (
        <section className="card" aria-labelledby="inv-title">
          <div className="toolbar">
            <h2 id="inv-title" style={{ marginRight: 'auto' }}>
              Inventory <span className="pill">{stats.total} total</span>{' '}
              {stats.expiring > 0 && <span className="pill expiring">{stats.expiring} expiring</span>}{' '}
              {stats.low > 0 && <span className="pill low-stock">{stats.low} low stock</span>}
            </h2>
            <label className="search" aria-label="Search by name">
              <svg className="search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>
              </svg>
              <input
                type="search"
                placeholder="Search by medicine name..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </label>
            <button className="btn ghost" onClick={loadMedicines} aria-label="Refresh">
              {loading ? <span className="spinner" /> : 'Refresh'}
            </button>
          </div>

          {error && <div className="error-box" role="alert">⚠ {error}</div>}
          {!error && loading && medicines.length === 0 && <div className="loading"><span className="spinner" /> Loading inventory...</div>}
          {!error && !loading && medicines.length === 0 && (
            <div className="empty">No medicines match your search.</div>
          )}
          {medicines.length > 0 && (
            <MedicineGrid medicines={medicines} onSell={(m) => setSellTarget(m)} />
          )}
        </section>
      )}

      {tab === 'add' && (
        <section className="card" aria-labelledby="add-title">
          <h2 id="add-title">Add a new medicine</h2>
          <AddMedicineForm onSubmit={handleAdd} />
        </section>
      )}

      {tab === 'sales' && (
        <section className="card" aria-labelledby="sales-title">
          <h2 id="sales-title">Sales history</h2>
          <SalesHistory sales={sales} onRefresh={loadSales} />
        </section>
      )}

      {sellTarget && (
        <SellDialog medicine={sellTarget} onCancel={() => setSellTarget(null)} onConfirm={handleSell} />
      )}

      <Modal
        open={modal.open}
        type={modal.type}
        title={modal.title}
        message={modal.message}
        onClose={closeModal}
      />
    </div>
  )
}
