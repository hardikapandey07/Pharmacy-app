@echo off
REM One-click launcher for ABC Pharmacy Medicine Tracker (native .NET)
REM Requires: .NET SDK 10.0.300+. (Node.js only needed if you want to rebuild the UI.)

cd /d "%~dp0\server\PharmacyApi"

echo.
echo === ABC Pharmacy: starting API + SPA at http://localhost:5080 ===
echo.

dotnet run
