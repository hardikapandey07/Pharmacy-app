@echo off
REM One-click launcher for ABC Pharmacy Medicine Tracker (Docker)
REM Make sure Docker Desktop is running before you run this.

echo.
echo === ABC Pharmacy: building and starting with Docker ===
echo.

cd /d "%~dp0"
docker compose up --build
