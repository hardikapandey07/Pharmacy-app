using System.ComponentModel.DataAnnotations;

namespace PharmacyApi.Models;

public class Medicine
{
    public Guid Id { get; set; } = Guid.NewGuid();

    [Required, StringLength(120, MinimumLength = 1)]
    public string Name { get; set; } = string.Empty;

    [StringLength(1000)]
    public string? Notes { get; set; }

    [Required]
    public DateTime ExpiryDate { get; set; }

    [Range(0, int.MaxValue)]
    public int Quantity { get; set; }

    [Range(0.0, 1_000_000.0)]
    public decimal Price { get; set; }

    [Required, StringLength(80)]
    public string Brand { get; set; } = string.Empty;

    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAtUtc { get; set; } = DateTime.UtcNow;
}

public class MedicineCreateDto
{
    [Required, StringLength(120, MinimumLength = 1)]
    public string Name { get; set; } = string.Empty;
    [StringLength(1000)] public string? Notes { get; set; }
    [Required] public DateTime ExpiryDate { get; set; }
    [Range(0, int.MaxValue)] public int Quantity { get; set; }
    [Range(0.0, 1_000_000.0)] public decimal Price { get; set; }
    [Required, StringLength(80)] public string Brand { get; set; } = string.Empty;
}
