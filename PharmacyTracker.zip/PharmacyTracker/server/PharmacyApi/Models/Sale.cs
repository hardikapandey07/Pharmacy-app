using System.ComponentModel.DataAnnotations;

namespace PharmacyApi.Models;

public class Sale
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid MedicineId { get; set; }
    public string MedicineName { get; set; } = string.Empty;
    public int Quantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal TotalPrice { get; set; }
    public DateTime SoldAtUtc { get; set; } = DateTime.UtcNow;
}

public class SaleCreateDto
{
    [Required] public Guid MedicineId { get; set; }
    [Range(1, int.MaxValue)] public int Quantity { get; set; }
}
