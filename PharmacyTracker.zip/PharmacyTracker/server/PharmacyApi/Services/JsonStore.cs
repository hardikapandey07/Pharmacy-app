using System.Text.Json;
using PharmacyApi.Models;

namespace PharmacyApi.Services;

public interface IJsonStore
{
    Task<List<Medicine>> GetMedicinesAsync(string? search = null, CancellationToken ct = default);
    Task<Medicine?> GetMedicineAsync(Guid id, CancellationToken ct = default);
    Task<Medicine> AddMedicineAsync(MedicineCreateDto dto, CancellationToken ct = default);
    Task<List<Sale>> GetSalesAsync(CancellationToken ct = default);
    Task<Sale> RecordSaleAsync(SaleCreateDto dto, CancellationToken ct = default);
}

public class JsonStore : IJsonStore
{
    private readonly string _medicinesPath;
    private readonly string _salesPath;
    private readonly SemaphoreSlim _lock = new(1, 1);
    private static readonly JsonSerializerOptions JsonOpts = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true
    };

    // In-memory cache to reduce disk IO for reads
    private List<Medicine>? _medsCache;
    private List<Sale>? _salesCache;

    public JsonStore(IWebHostEnvironment env, IConfiguration config)
    {
        var dataDir = config["Data:Directory"] ?? Path.Combine(env.ContentRootPath, "Data");
        Directory.CreateDirectory(dataDir);
        _medicinesPath = Path.Combine(dataDir, "medicines.json");
        _salesPath = Path.Combine(dataDir, "sales.json");
        SeedIfMissing();
    }

    private void SeedIfMissing()
    {
        if (!File.Exists(_medicinesPath))
        {
            var today = DateTime.UtcNow.Date;
            var seed = new List<Medicine>
            {
                new() { Name = "Paracetamol 500mg", Brand = "Cipla", Quantity = 120, Price = 25.50m, ExpiryDate = today.AddMonths(14), Notes = "Pain reliever and fever reducer" },
                new() { Name = "Amoxicillin 250mg", Brand = "Sun Pharma", Quantity = 8,   Price = 85.00m, ExpiryDate = today.AddMonths(8),  Notes = "Antibiotic" },
                new() { Name = "Cetirizine 10mg",   Brand = "Dr. Reddy's", Quantity = 45, Price = 32.75m, ExpiryDate = today.AddDays(20),   Notes = "Antihistamine" },
                new() { Name = "Metformin 500mg",   Brand = "Lupin",       Quantity = 5,  Price = 48.90m, ExpiryDate = today.AddDays(15),   Notes = "Diabetes - low stock & near expiry" },
                new() { Name = "Azithromycin 500mg",Brand = "Zydus",       Quantity = 60, Price = 125.00m,ExpiryDate = today.AddYears(2),   Notes = "Antibiotic" },
                new() { Name = "Pantoprazole 40mg", Brand = "Alkem",       Quantity = 30, Price = 55.25m, ExpiryDate = today.AddMonths(10), Notes = "Acid reflux" }
            };
            File.WriteAllText(_medicinesPath, JsonSerializer.Serialize(seed, JsonOpts));
        }
        if (!File.Exists(_salesPath))
            File.WriteAllText(_salesPath, "[]");
    }

    private async Task<List<Medicine>> LoadMedsAsync(CancellationToken ct)
    {
        if (_medsCache != null) return _medsCache;
        await using var fs = File.OpenRead(_medicinesPath);
        _medsCache = await JsonSerializer.DeserializeAsync<List<Medicine>>(fs, JsonOpts, ct) ?? new();
        return _medsCache;
    }
    private async Task<List<Sale>> LoadSalesAsync(CancellationToken ct)
    {
        if (_salesCache != null) return _salesCache;
        await using var fs = File.OpenRead(_salesPath);
        _salesCache = await JsonSerializer.DeserializeAsync<List<Sale>>(fs, JsonOpts, ct) ?? new();
        return _salesCache;
    }
    private async Task SaveMedsAsync(CancellationToken ct)
    {
        var tmp = _medicinesPath + ".tmp";
        await using (var fs = File.Create(tmp))
            await JsonSerializer.SerializeAsync(fs, _medsCache, JsonOpts, ct);
        File.Move(tmp, _medicinesPath, overwrite: true);
    }
    private async Task SaveSalesAsync(CancellationToken ct)
    {
        var tmp = _salesPath + ".tmp";
        await using (var fs = File.Create(tmp))
            await JsonSerializer.SerializeAsync(fs, _salesCache, JsonOpts, ct);
        File.Move(tmp, _salesPath, overwrite: true);
    }

    public async Task<List<Medicine>> GetMedicinesAsync(string? search = null, CancellationToken ct = default)
    {
        await _lock.WaitAsync(ct);
        try
        {
            var list = await LoadMedsAsync(ct);
            IEnumerable<Medicine> q = list;
            if (!string.IsNullOrWhiteSpace(search))
                q = list.Where(m => m.Name.Contains(search, StringComparison.OrdinalIgnoreCase));
            return q.OrderBy(m => m.ExpiryDate).ToList();
        }
        finally { _lock.Release(); }
    }

    public async Task<Medicine?> GetMedicineAsync(Guid id, CancellationToken ct = default)
    {
        await _lock.WaitAsync(ct);
        try { return (await LoadMedsAsync(ct)).FirstOrDefault(m => m.Id == id); }
        finally { _lock.Release(); }
    }

    public async Task<Medicine> AddMedicineAsync(MedicineCreateDto dto, CancellationToken ct = default)
    {
        await _lock.WaitAsync(ct);
        try
        {
            var list = await LoadMedsAsync(ct);
            var med = new Medicine
            {
                Name = dto.Name.Trim(),
                Notes = dto.Notes?.Trim(),
                ExpiryDate = dto.ExpiryDate,
                Quantity = dto.Quantity,
                Price = decimal.Round(dto.Price, 2),
                Brand = dto.Brand.Trim(),
                CreatedAtUtc = DateTime.UtcNow,
                UpdatedAtUtc = DateTime.UtcNow,
            };
            list.Add(med);
            await SaveMedsAsync(ct);
            return med;
        }
        finally { _lock.Release(); }
    }

    public async Task<List<Sale>> GetSalesAsync(CancellationToken ct = default)
    {
        await _lock.WaitAsync(ct);
        try { return (await LoadSalesAsync(ct)).OrderByDescending(s => s.SoldAtUtc).ToList(); }
        finally { _lock.Release(); }
    }

    public async Task<Sale> RecordSaleAsync(SaleCreateDto dto, CancellationToken ct = default)
    {
        await _lock.WaitAsync(ct);
        try
        {
            var meds = await LoadMedsAsync(ct);
            var med = meds.FirstOrDefault(m => m.Id == dto.MedicineId)
                      ?? throw new KeyNotFoundException("Medicine not found.");
            if (dto.Quantity <= 0) throw new ArgumentException("Quantity must be positive.");
            if (med.Quantity < dto.Quantity) throw new InvalidOperationException("Insufficient stock.");
            med.Quantity -= dto.Quantity;
            med.UpdatedAtUtc = DateTime.UtcNow;

            var sale = new Sale
            {
                MedicineId = med.Id,
                MedicineName = med.Name,
                Quantity = dto.Quantity,
                UnitPrice = med.Price,
                TotalPrice = decimal.Round(med.Price * dto.Quantity, 2),
                SoldAtUtc = DateTime.UtcNow
            };
            var sales = await LoadSalesAsync(ct);
            sales.Add(sale);
            await SaveMedsAsync(ct);
            await SaveSalesAsync(ct);
            return sale;
        }
        finally { _lock.Release(); }
    }
}
