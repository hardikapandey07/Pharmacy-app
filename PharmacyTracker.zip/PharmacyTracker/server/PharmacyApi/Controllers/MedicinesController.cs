using Microsoft.AspNetCore.Mvc;
using PharmacyApi.Models;
using PharmacyApi.Services;

namespace PharmacyApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class MedicinesController : ControllerBase
{
    private readonly IJsonStore _store;
    public MedicinesController(IJsonStore store) => _store = store;

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Medicine>>> Get([FromQuery] string? search, CancellationToken ct)
    {
        var meds = await _store.GetMedicinesAsync(search, ct);
        Response.Headers.CacheControl = "private, max-age=5";
        return Ok(meds);
    }

    [HttpGet("{id:guid}")]
    public async Task<ActionResult<Medicine>> GetOne(Guid id, CancellationToken ct)
    {
        var m = await _store.GetMedicineAsync(id, ct);
        return m is null ? NotFound() : Ok(m);
    }

    [HttpPost]
    public async Task<ActionResult<Medicine>> Create([FromBody] MedicineCreateDto dto, CancellationToken ct)
    {
        if (!ModelState.IsValid) return ValidationProblem(ModelState);
        if (dto.ExpiryDate.Date < DateTime.UtcNow.Date)
        {
            ModelState.AddModelError(nameof(dto.ExpiryDate), "Expiry date cannot be in the past.");
            return ValidationProblem(ModelState);
        }
        var med = await _store.AddMedicineAsync(dto, ct);
        return CreatedAtAction(nameof(GetOne), new { id = med.Id }, med);
    }
}
