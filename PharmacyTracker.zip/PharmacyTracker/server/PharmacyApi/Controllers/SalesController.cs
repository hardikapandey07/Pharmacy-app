using Microsoft.AspNetCore.Mvc;
using PharmacyApi.Models;
using PharmacyApi.Services;

namespace PharmacyApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SalesController : ControllerBase
{
    private readonly IJsonStore _store;
    public SalesController(IJsonStore store) => _store = store;

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Sale>>> Get(CancellationToken ct)
        => Ok(await _store.GetSalesAsync(ct));

    [HttpPost]
    public async Task<ActionResult<Sale>> Create([FromBody] SaleCreateDto dto, CancellationToken ct)
    {
        if (!ModelState.IsValid) return ValidationProblem(ModelState);
        try
        {
            var sale = await _store.RecordSaleAsync(dto, ct);
            return Created($"/api/sales/{sale.Id}", sale);
        }
        catch (KeyNotFoundException) { return NotFound(new { message = "Medicine not found." }); }
        catch (InvalidOperationException ex) { return Conflict(new { message = ex.Message }); }
        catch (ArgumentException ex) { return BadRequest(new { message = ex.Message }); }
    }
}
