using PharmacyApi.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers()
    .AddJsonOptions(o =>
    {
        o.JsonSerializerOptions.PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase;
        o.JsonSerializerOptions.PropertyNameCaseInsensitive = true;
    });
builder.Services.AddSingleton<IJsonStore, JsonStore>();
builder.Services.AddCors(o => o.AddDefaultPolicy(p =>
    p.WithOrigins("http://localhost:5173", "http://127.0.0.1:5173")
     .AllowAnyHeader().AllowAnyMethod()));
builder.Services.AddResponseCompression();
builder.Services.AddEndpointsApiExplorer();

var app = builder.Build();

app.UseResponseCompression();
app.UseCors();
app.UseDefaultFiles();
app.UseStaticFiles();
app.MapControllers();
// SPA fallback: unknown non-API routes serve index.html
app.MapFallbackToFile("index.html");

app.Run();

public partial class Program { }
