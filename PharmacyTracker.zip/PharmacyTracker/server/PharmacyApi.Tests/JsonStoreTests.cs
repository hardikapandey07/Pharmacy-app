using System.Text.Json;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.AspNetCore.Hosting;
using PharmacyApi.Models;
using PharmacyApi.Services;

namespace PharmacyApi.Tests;

internal class FakeEnv : IWebHostEnvironment
{
    public string WebRootPath { get; set; } = "";
    public Microsoft.Extensions.FileProviders.IFileProvider WebRootFileProvider { get; set; } = null!;
    public string ApplicationName { get; set; } = "test";
    public Microsoft.Extensions.FileProviders.IFileProvider ContentRootFileProvider { get; set; } = null!;
    public string ContentRootPath { get; set; } = "";
    public string EnvironmentName { get; set; } = "Test";
}

public class JsonStoreTests : IDisposable
{
    private readonly string _tmpDir;
    private readonly JsonStore _store;

    public JsonStoreTests()
    {
        _tmpDir = Path.Combine(Path.GetTempPath(), "pharmacy-tests-" + Guid.NewGuid());
        Directory.CreateDirectory(_tmpDir);
        var env = new FakeEnv { ContentRootPath = _tmpDir };
        var cfg = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?> { { "Data:Directory", _tmpDir } })
            .Build();
        _store = new JsonStore(env, cfg);
    }

    public void Dispose() { try { Directory.Delete(_tmpDir, true); } catch { } }

    [Fact]
    public async Task Seeds_initial_medicines_on_first_run()
    {
        var meds = await _store.GetMedicinesAsync();
        Assert.NotEmpty(meds);
        Assert.Contains(meds, m => m.Name.Contains("Paracetamol"));
    }

    [Fact]
    public async Task AddMedicine_persists_and_rounds_price()
    {
        var created = await _store.AddMedicineAsync(new MedicineCreateDto
        {
            Name = "Test Med", Brand = "TB", Quantity = 5,
            Price = 12.345m, ExpiryDate = DateTime.UtcNow.AddMonths(6), Notes = "n"
        });
        Assert.Equal(12.35m, created.Price);
        var fetched = await _store.GetMedicineAsync(created.Id);
        Assert.NotNull(fetched);
        Assert.Equal("Test Med", fetched!.Name);
    }

    [Fact]
    public async Task Search_filters_by_name_case_insensitive()
    {
        var filtered = await _store.GetMedicinesAsync("paraCETA");
        Assert.All(filtered, m => Assert.Contains("paraceta", m.Name, StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task RecordSale_decrements_stock_and_creates_sale()
    {
        var med = (await _store.GetMedicinesAsync()).First(m => m.Quantity >= 5);
        var before = med.Quantity;
        var sale = await _store.RecordSaleAsync(new SaleCreateDto { MedicineId = med.Id, Quantity = 2 });
        var after = (await _store.GetMedicineAsync(med.Id))!.Quantity;
        Assert.Equal(before - 2, after);
        Assert.Equal(med.Name, sale.MedicineName);
        Assert.Equal(decimal.Round(med.Price * 2, 2), sale.TotalPrice);
    }

    [Fact]
    public async Task RecordSale_throws_when_insufficient_stock()
    {
        var med = await _store.AddMedicineAsync(new MedicineCreateDto
        {
            Name = "Low", Brand = "B", Quantity = 1, Price = 10m, ExpiryDate = DateTime.UtcNow.AddMonths(1)
        });
        await Assert.ThrowsAsync<InvalidOperationException>(() =>
            _store.RecordSaleAsync(new SaleCreateDto { MedicineId = med.Id, Quantity = 5 }));
    }

    [Fact]
    public async Task RecordSale_throws_when_medicine_missing()
    {
        await Assert.ThrowsAsync<KeyNotFoundException>(() =>
            _store.RecordSaleAsync(new SaleCreateDto { MedicineId = Guid.NewGuid(), Quantity = 1 }));
    }
}
