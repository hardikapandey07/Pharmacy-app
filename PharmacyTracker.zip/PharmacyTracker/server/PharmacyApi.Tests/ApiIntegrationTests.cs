using System.Net;
using System.Net.Http.Json;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Hosting;
using PharmacyApi.Models;

namespace PharmacyApi.Tests;

public class ApiFactory : WebApplicationFactory<Program>
{
    public string DataDir { get; } = Path.Combine(Path.GetTempPath(), "pharmacy-api-" + Guid.NewGuid());

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        Directory.CreateDirectory(DataDir);
        builder.ConfigureAppConfiguration((_, cfg) =>
            cfg.AddInMemoryCollection(new Dictionary<string, string?> { { "Data:Directory", DataDir } }));
    }

    protected override void Dispose(bool disposing)
    {
        base.Dispose(disposing);
        try { Directory.Delete(DataDir, true); } catch { }
    }
}

public class ApiIntegrationTests : IClassFixture<ApiFactory>
{
    private readonly ApiFactory _f;
    public ApiIntegrationTests(ApiFactory f) => _f = f;

    [Fact]
    public async Task GET_medicines_returns_seeded_list()
    {
        var client = _f.CreateClient();
        var meds = await client.GetFromJsonAsync<List<Medicine>>("/api/medicines");
        Assert.NotNull(meds);
        Assert.NotEmpty(meds!);
    }

    [Fact]
    public async Task POST_medicine_validates_required_fields()
    {
        var client = _f.CreateClient();
        var resp = await client.PostAsJsonAsync("/api/medicines", new { name = "", brand = "", quantity = -1, price = -5, expiryDate = DateTime.UtcNow.AddYears(1) });
        Assert.Equal(HttpStatusCode.BadRequest, resp.StatusCode);
    }

    [Fact]
    public async Task POST_medicine_rejects_past_expiry()
    {
        var client = _f.CreateClient();
        var resp = await client.PostAsJsonAsync("/api/medicines", new MedicineCreateDto
        {
            Name = "X", Brand = "B", Quantity = 1, Price = 10m, ExpiryDate = DateTime.UtcNow.AddDays(-1)
        });
        Assert.Equal(HttpStatusCode.BadRequest, resp.StatusCode);
    }

    [Fact]
    public async Task POST_medicine_creates_and_can_be_fetched_back()
    {
        var client = _f.CreateClient();
        var create = await client.PostAsJsonAsync("/api/medicines", new MedicineCreateDto
        {
            Name = "Ibuprofen", Brand = "Bayer", Quantity = 20, Price = 15.5m,
            ExpiryDate = DateTime.UtcNow.AddMonths(12), Notes = "Anti-inflammatory"
        });
        Assert.Equal(HttpStatusCode.Created, create.StatusCode);
        var created = await create.Content.ReadFromJsonAsync<Medicine>();
        Assert.NotNull(created);

        var list = await client.GetFromJsonAsync<List<Medicine>>("/api/medicines?search=ibu");
        Assert.NotNull(list);
        Assert.Contains(list!, m => m.Id == created!.Id);
    }

    [Fact]
    public async Task POST_sale_decrements_quantity()
    {
        var client = _f.CreateClient();
        var meds = await client.GetFromJsonAsync<List<Medicine>>("/api/medicines");
        var med = meds!.First(m => m.Quantity >= 3);
        var before = med.Quantity;
        var resp = await client.PostAsJsonAsync("/api/sales", new SaleCreateDto { MedicineId = med.Id, Quantity = 2 });
        Assert.Equal(HttpStatusCode.Created, resp.StatusCode);
        var again = await client.GetFromJsonAsync<Medicine>($"/api/medicines/{med.Id}");
        Assert.Equal(before - 2, again!.Quantity);
    }

    [Fact]
    public async Task POST_sale_conflicts_when_oversold()
    {
        var client = _f.CreateClient();
        var create = await client.PostAsJsonAsync("/api/medicines", new MedicineCreateDto
        {
            Name = "LowStock", Brand = "X", Quantity = 1, Price = 1m, ExpiryDate = DateTime.UtcNow.AddMonths(6)
        });
        var med = (await create.Content.ReadFromJsonAsync<Medicine>())!;
        var resp = await client.PostAsJsonAsync("/api/sales", new SaleCreateDto { MedicineId = med.Id, Quantity = 10 });
        Assert.Equal(HttpStatusCode.Conflict, resp.StatusCode);
    }
}
