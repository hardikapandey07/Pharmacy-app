@echo off
REM ============================================================
REM  ABC Pharmacy - One-click launcher (Frontend + Backend)
REM
REM  Runs the ASP.NET Core API, which serves the React SPA from
REM  wwwroot. If the SPA has not been built yet, we build it first
REM  (requires Node.js). Then we open the browser.
REM ============================================================

setlocal
cd /d "%~dp0"

echo.
echo === ABC Pharmacy Medicine Tracker - starting up ===
echo.

REM --- Check .NET SDK ---
where dotnet >nul 2>&1
if errorlevel 1 (
  echo [ERROR] .NET SDK not found. Install from https://dotnet.microsoft.com/download
  pause
  exit /b 1
)

REM --- If the pre-built SPA is missing, build it now ---
if not exist "server\PharmacyApi\wwwroot\index.html" (
  echo [i] wwwroot is empty - building the React SPA...
  where npm >nul 2>&1
  if errorlevel 1 (
    echo [ERROR] Node.js not found and SPA is not pre-built. Install Node.js 20+ from https://nodejs.org
    pause
    exit /b 1
  )
  pushd web
  if not exist "node_modules" (
    echo [i] Installing npm dependencies ^(first run only^)...
    call npm install --no-audit --no-fund
    if errorlevel 1 ( popd & echo [ERROR] npm install failed. & pause & exit /b 1 )
  )
  call npm run build
  if errorlevel 1 ( popd & echo [ERROR] SPA build failed. & pause & exit /b 1 )
  popd
)

REM --- Launch the API in a new window (serves API + SPA together) ---
echo [i] Starting the API on http://localhost:5080 ...
start "ABC Pharmacy API + UI" cmd /k "cd /d ""%~dp0server\PharmacyApi"" && dotnet run --no-launch-profile --urls http://localhost:5080"

REM --- Give the server a moment, then open the browser ---
echo [i] Waiting for the server to come up...
timeout /t 8 /nobreak >nul
start "" http://localhost:5080

echo.
echo === Opened http://localhost:5080 in your browser ===
echo     Close the "ABC Pharmacy API + UI" window to stop the server.
echo.
endlocal
