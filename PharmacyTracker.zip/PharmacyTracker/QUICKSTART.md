# Quickstart — ABC Pharmacy Medicine Tracker

Three ways to run this project. Pick the one that matches your setup.

---

## Option 1 — Docker (recommended, zero local setup)

Works on Windows, macOS, Linux. Only needs Docker Desktop.

```bash
docker compose up --build
```

Open **<http://localhost:5080>** — done.

- To stop: `Ctrl+C`, then `docker compose down`.
- Data persists in a Docker volume called `pharmacy-data`.

---

## Option 2 — Native (no Docker)

**Prerequisites**: .NET SDK 10.0.300+ and Node.js 20+.

```bash
# 1. Build the React SPA into the API's wwwroot
cd web
npm install
npm run build

# 2. Run the API (serves the SPA + exposes /api endpoints)
cd ../server/PharmacyApi
dotnet run
```

Open **<http://localhost:5080>**.

> If you cloned the repo and don't want to install Node, the pre-built SPA is already committed in `server/PharmacyApi/wwwroot/`. Skip step 1 and go straight to `dotnet run`.

---

## Option 3 — Dev mode with hot reload

Two terminals.

```bash
# Terminal 1: API
cd server/PharmacyApi
dotnet run
```

```bash
# Terminal 2: Vite dev server
cd web
npm install
npm run dev
```

Open **<http://localhost:5173>**. Vite proxies `/api/*` to the API.

---

## Running the tests

**React tests**
```bash
cd web
npm test
```
Expected: `15 passed` across 3 files.

**.NET tests**
```bash
cd server/PharmacyApi.Tests
dotnet test
```

---

## What to check in the UI

The seeded data makes both color rules visible immediately on the Inventory tab:
- **Red row** — *Cetirizine* (expiring in ~20 days) and *Metformin* (expiring in ~15 days)
- **Yellow row** — *Amoxicillin* (qty 8)

Try:
1. **Search** by typing `para` — list filters to Paracetamol.
2. **Add a medicine** on the "Add Medicine" tab — try an empty name, a past expiry, a price with 3 decimals → see the validation errors.
3. **Sell** — click Sell on any row, record a sale, watch quantity drop and the sale appear under the Sales tab.
