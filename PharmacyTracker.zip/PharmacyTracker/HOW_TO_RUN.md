# How to run — ABC Pharmacy Medicine Tracker

Follow one of these three paths. The **easiest** is first.

---

## 🟢 Path 1 — Double-click (Windows, one-click)

1. **Install prerequisites once** (skip any you already have):
   - **.NET SDK 10.0.300+** — <https://dotnet.microsoft.com/download>
   - *(Optional)* **Node.js 20+** — <https://nodejs.org> *(only if you want to rebuild the UI; a pre-built copy is already included)*
2. **Double-click `start-app.bat`** at the project root.

That's it. The script will:
- Check your tools
- Build the React UI if needed
- Start the ASP.NET Core API on port **5080**
- Open <http://localhost:5080> in your default browser

To stop: close the console window titled "ABC Pharmacy API + UI".

---

## 🔵 Path 2 — Command line (Mac, Linux, or Windows)

**Prerequisite:** .NET SDK 10.0.300+.

```bash
cd server/PharmacyApi
dotnet run
```

Open **<http://localhost:5080>**.

The pre-built SPA is already inside `server/PharmacyApi/wwwroot/`, so you don't need Node.js for this path.

---

## 🟣 Path 3 — Dev mode with hot-reload (for code review)

Two terminals, so you can edit React and the API side by side.

```bash
# Terminal 1 — backend
cd server/PharmacyApi
dotnet run
```

```bash
# Terminal 2 — frontend (hot reload)
cd web
npm install
npm run dev
```

Open <http://localhost:5173>. Vite proxies `/api/*` to the API.

---

## 🐳 Path 4 — Docker (no local .NET or Node needed)

Only Docker required.

```bash
docker compose up --build
```

Open <http://localhost:5080>. Data persists in a Docker volume.

To stop: `Ctrl+C`, then `docker compose down`.

---

## Running the tests

### Frontend (Vitest + React Testing Library)
```bash
cd web
npm install
npm test
```
Expected: **15 tests passing** across 3 files (API helpers, add-form validation, grid rendering/coloring).

### Backend (xUnit)
```bash
cd server/PharmacyApi.Tests
dotnet test
```
Expected: **11 tests passing** (JsonStore unit tests + HTTP integration via `WebApplicationFactory`).

---

## What you should see when it runs

1. On **Inventory**, the seeded data instantly shows both color rules:
   - 🔴 **Red rows** — *Cetirizine* (expires in ~20 days), *Metformin* (expires in ~15 days)
   - 🟡 **Yellow row** — *Amoxicillin* (quantity 8)
2. **Search** — type `para` → the list filters to Paracetamol.
3. **Add Medicine** tab — try to submit empty, or a past expiry, or a price with 3 decimals → see inline validation.
4. **Sell** — click Sell on any row → modal opens → confirm → stock drops, success modal appears, and the sale shows up under the Sales tab.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `port 5080 already in use` | Change the port in `server/PharmacyApi/Properties/launchSettings.json`, or free the port. |
| On Windows: *"An Application Control policy has blocked this file"* | Your machine has **Smart App Control** enabled. Either disable it (Settings → Privacy & Security → Windows Security → App & browser control → Smart App Control), or run via Docker (Path 4). |
| Empty `wwwroot/` after a fresh clone | `cd web && npm install && npm run build` — writes into `server/PharmacyApi/wwwroot`. |
| Sales don't persist across restart | They do — check `server/PharmacyApi/Data/sales.json`. In Docker, data lives in the `pharmacy-data` volume. |

---

## Project layout

```
PharmacyTracker/
├── HOW_TO_RUN.md                ← you're here
├── README.md                    ← full spec coverage + architecture
├── QUICKSTART.md                ← one-page cheat sheet
├── start-app.bat                ← one-click Windows launcher (frontend + backend)
├── Dockerfile  docker-compose.yml
├── server/
│   ├── PharmacyApi/             ← ASP.NET Core 10 Web API (serves SPA too)
│   │   ├── Controllers/  Models/  Services/  Data/  wwwroot/
│   │   └── Program.cs
│   └── PharmacyApi.Tests/       ← xUnit tests
└── web/                         ← React (Vite) source + Vitest tests
    ├── src/
    │   ├── App.jsx
    │   ├── api.js
    │   ├── styles.css           ← fresh indigo + rose theme
    │   └── components/
    │       ├── MedicineGrid.jsx
    │       ├── AddMedicineForm.jsx
    │       ├── SellDialog.jsx
    │       ├── SalesHistory.jsx
    │       └── Modal.jsx        ← replaces old Toasts for feedback
    ├── package.json
    └── vite.config.js
```
