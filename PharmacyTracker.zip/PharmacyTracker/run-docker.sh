#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo
echo "=== ABC Pharmacy: building and starting with Docker ==="
echo
docker compose up --build
