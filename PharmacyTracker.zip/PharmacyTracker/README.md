# ABC Pharmacy — Medicine Tracker

A Single Page Application for **ABC Pharmacy** to track medicines and record sales.

- **Backend**: ASP.NET Core 10 Web API (controllers)
- **Frontend**: React 18 + Vite
- **Storage**: JSON files on the server (`Data/medicines.json`, `Data/sales.json`) — no database required
- **Deployment**: single `dotnet run` boots the API *and* serves the built React SPA from `wwwroot/`

---

## 🚀 Quickstart

**Easiest (Docker):**
```bash
docker compose up --build
```
Open **<http://localhost:5080>**.

**Native (no Docker):**
```bash
cd server/PharmacyApi
dotnet run
```
Open **<http://localhost:5080>**.

See [QUICKSTART.md](./QUICKSTART.md) for more detail and the dev-mode workflow.

---

## Requirements covered

| Requirement | Where it lives |
|---|---|
| View list of medicines | `MedicinesController.Get` + `MedicineGrid.jsx` |
| Grid shows every attribute **except Notes** | `MedicineGrid.jsx` (6 columns: Name, Brand, Expiry, Qty, Price, Actions) |
| **Red** rows for expiry < 30 days | `rowFlag()` + `tr.expiring` CSS in `styles.css` |
| **Yellow** rows for quantity < 10 | `rowFlag()` + `tr.low-stock` CSS |
| Add a medicine | `AddMedicineForm.jsx` → `POST /api/medicines` |
| Record sales | `SellDialog.jsx` + `SalesController.Create` |
| Search by name (good-to-have) | `App.jsx` debounced input → `?search=` query |
| .NET Core for API | ASP.NET Core 10 |
| JavaScript framework | React (Vite) |
| Data in JSON on server | `JsonStore.cs` with atomic writes and in-memory cache |

---

## Project structure

```
PharmacyTracker/
├── PharmacyTracker.sln
├── server/
│   ├── PharmacyApi/              ASP.NET Core Web API
│   │   ├── Controllers/
│   │   │   ├── MedicinesController.cs
│   │   │   └── SalesController.cs
│   │   ├── Models/
│   │   │   ├── Medicine.cs
│   │   │   └── Sale.cs
│   │   ├── Services/
│   │   │   └── JsonStore.cs      JSON persistence (thread-safe, atomic, cached)
│   │   ├── Data/                 (medicines.json + sales.json seeded on first run)
│   │   ├── wwwroot/              Built React SPA
│   │   └── Program.cs            DI + CORS + static files + SPA fallback
│   └── PharmacyApi.Tests/        xUnit — unit + integration
│       ├── JsonStoreTests.cs
│       └── ApiIntegrationTests.cs (WebApplicationFactory)
└── web/                          React (Vite) source
    ├── src/
    │   ├── App.jsx
    │   ├── api.js                fetch layer + in-memory cache + helpers
    │   ├── styles.css            Light/dark themes, responsive grid
    │   ├── components/
    │   │   ├── MedicineGrid.jsx
    │   │   ├── AddMedicineForm.jsx
    │   │   ├── SellDialog.jsx
    │   │   ├── SalesHistory.jsx
    │   │   └── Toasts.jsx
    │   └── test/                 Vitest + React Testing Library
    ├── index.html
    ├── package.json
    └── vite.config.js
```

---

## Prerequisites

- **.NET SDK 10.0.300+** (project targets `net10.0`)
- **Node.js 20+** and npm

---

## Run the whole thing (interviewer-friendly)

The simplest path: run the API, which serves the pre-built React UI from `wwwroot/`.

```bash
cd server/PharmacyApi
dotnet run
```

Then open **<http://localhost:5080/>** in a browser. You will see the SPA with seeded data that immediately demonstrates both color rules (one red row near expiry, one yellow row with low stock).

> If `wwwroot/` is empty (e.g. after a fresh `git clone`), rebuild the UI first — see "Build the frontend" below.

### Build the frontend

```bash
cd web
npm install
npm run build        # outputs into ../server/PharmacyApi/wwwroot
```

### Frontend dev mode (hot reload)

Run two terminals:

```bash
# Terminal 1 — API
cd server/PharmacyApi
dotnet run

# Terminal 2 — Vite dev server with proxy to API
cd web
npm run dev
```

Open **<http://localhost:5173/>**. Vite proxies `/api/*` to the API at `:5080`.

---

## API reference

| Method | Path | Body | Notes |
|---|---|---|---|
| GET  | `/api/medicines?search=xyz` | — | List, name-filtered (case-insensitive). Sends `Cache-Control: private, max-age=5` |
| GET  | `/api/medicines/{id}` | — | Single medicine |
| POST | `/api/medicines` | `MedicineCreateDto` | Server-side validation; rejects past expiry |
| GET  | `/api/sales` | — | Sales history (newest first) |
| POST | `/api/sales` | `{ medicineId, quantity }` | Decrements stock; 409 if insufficient |

**`MedicineCreateDto`**
```jsonc
{
  "name": "Paracetamol 500mg",   // required, 1–120 chars
  "brand": "Cipla",              // required, 1–80 chars
  "expiryDate": "2027-05-30T00:00:00Z", // ISO; must be today or future
  "quantity": 100,               // integer >= 0
  "price": 25.50,                // >= 0; stored rounded to 2dp
  "notes": "Pain reliever"       // optional, <= 1000 chars
}
```

---

## Tests

### Backend (xUnit)

```bash
cd server/PharmacyApi.Tests
dotnet test
```

Covers:
- `JsonStore` seeds, add, search (case-insensitive), price rounding, sale stock decrement, insufficient-stock & missing-medicine error paths.
- Full HTTP round-trip via `WebApplicationFactory`: list, validation (bad fields and past expiry), create + fetch back, sale success, sale conflict (oversold).

### Frontend (Vitest + React Testing Library)

```bash
cd web
npm test
```

Covers:
- Pure helpers: `daysUntil`, `rowFlag` (red > yellow precedence), `inr` currency formatting
- `AddMedicineForm`: disables submit until valid, submits payload correctly, rejects >2 decimal price
- `MedicineGrid`: renders one row per medicine, applies `expiring` / `low-stock` classes, hides Notes column, fires `onSell`

---

## Performance / UX notes

- **Client-side cache** for the medicines list (3s TTL) with automatic invalidation on add/sell — the grid feels instant when flipping tabs.
- **Debounced search** (250ms) so typing doesn't spam the API.
- **Abortable fetch** — stale in-flight requests are cancelled when the search term changes.
- **Background refresh every 15s** (paused when the browser tab is hidden).
- **Response compression** on the server.
- **Atomic file writes** (`*.tmp` then `File.Move`) so `medicines.json` can never be half-written during a crash.
- **In-memory cache** inside `JsonStore` — reads don't hit disk once loaded.
- **Responsive**: grid scrolls horizontally below 720px, header tabs stack to full width on phones.
- **Dark mode**: automatic via `prefers-color-scheme`.
- **Accessibility**: labelled inputs, focus rings, `aria-selected` on tabs, `role="dialog"` on the sell modal with `Escape` to close.

---

## Known environment note

This project is complete and ready to run. If you ever encounter an "Application Control policy has blocked this file" error when loading .NET DLLs or Node `.node` bindings, that is a Windows Smart App Control / WDAC machine policy — unrelated to this project. It does not affect normal development machines.
